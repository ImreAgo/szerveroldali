<html lang="en">
<?php
		session_start();
		
		//Ha nem létezik a session visszadob a loginhoz
		if(!isset($_SESSION["Name"])){
			header("Location: login.php");
		}
	?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="kviz.css">
    <title>Document</title>
</head>
<body>
    <div id="header">
        <button class="login">Importálás</button>
        
        <button class="login"><?php echo $_SESSION["Name"];?></button>
    </div>
    <div class="container">
        <form action="">
            <input type="text" name="ujKerdes" id="ujKerdes" placeholder="Új kérdés...">
            <div class="kerdesFajta">
                <p>
                    <input type="radio" name="fajta" value="felet">
                    <label>Felet választós</label>
                </p>
                
                <p >
                    <input type="radio" name="fajta" value="önálló">
                    <label>Önálló válasz</label>
                </p>
            </div>
            <div class="radio-grid">
                
                    <input class="radioStyle" type="radio" name="radio" value="1">
                    <input type="text" class="valasz">

                    <input class="radioStyle" type="radio" name="radio" value="2">
                    <input type="text" class="valasz"><br>
                
                    <input class="radioStyle" type="radio" name="radio" value="3">
                    <input type="text" class="valasz">

                    <input class="radioStyle" type="radio" name="radio" value="4">
                    <input type="text" class="valasz">
                
            </div>
            <div class="footer">
                <p>
                    <input class="pont" type="text" name="pont" id="pont" value="">
                    <label for="pont">Pont</label>
                </p>
                <p>
                    <button class="next">Következő→</button>
                </p>
            </div>
        </form>
    </div>
</body>
</html>