<?php
// Function to get all available quizzes
function getQuizzes($conn)
{
    $quizzes = [];
    $sql = "SELECT * FROM quizes";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $quizzes[] = $row;
        }
    }

    return $quizzes;
}

// Function to check answers
function checkAnswers($selectedAnswer, $correctAnswer)
{
    $isCorrect = ($selectedAnswer == $correctAnswer);

    return json_encode(["isCorrect" => $isCorrect]);
}
?>
