<?php
session_start();
include 'db.php';
include 'function.php'; // Add this line to include functions.php
?>

<?php if (!isset($_GET['quizId']) || empty($_GET['quizId'])) : ?>
    
    <h2 class="cim" style="color: black; border-radius: 20px; padding: 10px; width: 500px; background-color: #8f8f8f; font-size: 24px; text-align: center; position: absolute; left: 520px">Válassz egy kitöltendő kvízt:</h2>
    <ol style=" width: 500px;   background-color: grey; display: flex; align-items: center; flex-direction: column; border-radius: 20px; position: absolute; left: 500px; top: 100px; ">
        <?php $availableQuizzes = getQuizzes($conn); ?>
        <?php if (isset($availableQuizzes)): ?>
            <?php foreach ($availableQuizzes as $quiz) : ?>
                <a href="?quizId=<?php echo $quiz['id']; ?>" style="text-decoration: none; color: black; font-size: larger;"><li style="text-align: center; width: 200px; padding: 20px; margin: 20px;  border-radius: 50px; background-color: #8f8f8f; border: 2px solid white;"><?php echo $quiz['name']; ?></li></a>
            <?php endforeach; ?>
        <?php endif; ?>
    </ol>
<?php else : ?>
    <?php
    $quizId = $_GET['quizId'];

    // Fetch questions for the selected quiz
    $sqlQuiz = "SELECT * FROM quizes WHERE id = $quizId";
    $resultQuiz = $conn->query($sqlQuiz);

    if ($resultQuiz->num_rows > 0) {
        $rowQuiz = $resultQuiz->fetch_assoc();
        $questionIds = $rowQuiz['questionIds'];

        // Fetch correct answers for the selected quiz
        $sqlAnswers = "SELECT id, correct FROM questions WHERE id IN ($questionIds)";
        if (!empty($questionIds)) {
            $resultAnswers = $conn->query($sqlAnswers);

            if ($resultAnswers->num_rows > 0) {
                $correctAnswers = [];
                while ($rowAnswer = $resultAnswers->fetch_assoc()) {
                    $correctAnswers[] = $rowAnswer['correct'];
                }
            }
        }

        // Get questions for the quiz
        $quizQuestions = getQuestions($conn, $questionIds);
    }
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="kitoltesStyle.css">
    <style>
        /* Add styling for correct and incorrect answers */
        .correct {
            background-color: green;
        }

        .incorrect {
            background-color: red;
        }
        .locked {
        pointer-events: none; /* Disable click events */
        opacity: 0.5; /* Reduce opacity to visually indicate the answer is locked */
    }
        
    </style>
    <title>Kitöltés</title>
    <script>
    let currentQuestionIndex = 0;
    let quizQuestions = [];
    let correctAnswers = [];

    function loadQuestions() {
        // Fetch questions from the server using AJAX
        const quizId = getParameterByName('quizId');
        const url = `loadQuestions.php?quizId=${quizId}`;

        fetch(url)
            .then(response => response.json())
            .then(data => {
                quizQuestions = data;
                loadQuestion();
            })
            .catch(error => console.error('Error fetching questions:', error));
    }

    let totalPoints = 0; // Variable to store the total points

function checkAnswer(selectedAnswer) {
    const correctAnswer = correctAnswers[currentQuestionIndex];

    // Lock all answers to prevent further clicks
    document.querySelectorAll('.answer-container div').forEach(answer => {
        answer.classList.add('locked');
    });

    // Remove previous styling from all answers
    document.querySelectorAll('.answer-container div').forEach(answer => {
        answer.classList.remove('correct', 'incorrect');
    });

    // Add styling based on the correctness of the selected answer
    if (selectedAnswer == correctAnswer) {
        document.querySelector(`.answer${selectedAnswer}`).classList.add('correct');

        // Increment total points if the answer is correct
        totalPoints += parseInt(quizQuestions[currentQuestionIndex]['point']);
    } else {
        document.querySelector(`.answer${selectedAnswer}`).classList.add('incorrect');
    }

    // Optionally, you can perform additional actions here based on the correctness

    // Move to the next question after checking the answer
    setTimeout(nextQuestion, 1000);
}
    function loadQuestion() {
        const question = quizQuestions[currentQuestionIndex];
        document.querySelector('.question').innerText = question['question'];
        document.querySelector('.answer1').innerText = question['answer1'];
        document.querySelector('.answer2').innerText = question['answer2'];
        document.querySelector('.answer3').innerText = question['answer3'];
        document.querySelector('.answer4').innerText = question['answer4'];

        // Remove previous styling from all answers
        document.querySelectorAll('.answer-container div').forEach(answer => {
            answer.classList.remove('correct', 'incorrect');
        });

        // Store the correct answer for the current question
        correctAnswers[currentQuestionIndex] = question['correct'];
    }

    function nextQuestion() {
    // Unlock all answers for the next question
    document.querySelectorAll('.answer-container div').forEach(answer => {
        answer.classList.remove('locked');
    });

    currentQuestionIndex++;

    if (currentQuestionIndex < quizQuestions.length) {
        loadQuestion();
    } else {
        // Quiz completed, show total points
        finishQuiz();
        // Optionally, you can redirect to another page or perform another action

        // Reset total points for a new quiz session
        totalPoints = 0;
    }
}

function lockAllAnswers() {
    // Add the "locked" class to all answer elements
    document.querySelectorAll('.answer-container div').forEach(answer => {
        answer.classList.add('locked');
    });
}

function unlockAllAnswers() {
    // Remove the "locked" class from all answer elements
    document.querySelectorAll('.answer-container div').forEach(answer => {
        answer.classList.remove('locked');
    });
}


    // Function to get query parameters from the URL
    function getParameterByName(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    function confirmFinish() {
    const result = confirm("Biztosan befejezed a kvízt?");
    if (result) {
        // User confirmed, finish the quiz
        finishQuiz();
    } else {
        // User canceled, continue with the quiz
        // You may add additional logic here if needed
    }
}

function finishQuiz() {
    // Optionally, you can perform any actions before finishing the quiz

    // Calculate and set total points
    const totalPointsText = `Elért pontok: ${totalPoints}`;
    document.getElementById('totalPointsText').innerText = totalPointsText;

    // Display the completion div
    displayCompletionDiv();

    // Hide the confirmation div
    hideConfirmationDiv();

    // Optionally, you can redirect to another page or perform another action

    // Reset total points for a new quiz session
    totalPoints = 0;
}

// Function to hide the completion div
function hideCompletionDiv() {
    document.getElementById('completionDiv').style.display = 'none';
}
function hideConfirmationDiv() {
    document.getElementById('confirmationDiv').style.display = 'none';
}
function displayCompletionDiv() {
    document.getElementById('completionDiv').style.display = 'flex';
}
function confirmFinish() {
    // Display the confirmation div
    document.getElementById('confirmationDiv').style.display = 'flex';
}
function cancelFinish() {
    // Hide the confirmation div
    hideConfirmationDiv();
}
    // Initial load
    document.addEventListener('DOMContentLoaded', loadQuestions);
</script>

</head>
<body>
    <div id="header"> 
        <a href="http://localhost/szerveroldali/laci_verzio/quiz/index.php"><button id="back" class="login">⬅</button></a>
        <button class="login"><?php echo $_SESSION["Name"];?></button>
        <button class="login" ><a href="logout.php">Kijelentkezés</a></button>
    </div>

    <div class="big-container">
        <div class="quiz-container">
            <div class="question"></div>
            <div class="answer-container">
                <div class="answer1" onclick="checkAnswer(1)"></div>
                <div class="answer2" onclick="checkAnswer(2)"></div>
            </div>
            <div class="answer-container">
                <div class="answer3" onclick="checkAnswer(3)"></div>
                <div class="answer4" onclick="checkAnswer(4)"></div>
            </div>
            <div class="buttons-container">
                <button onclick="confirmFinish()">Befejezés</button>
            </div>
        </div>
    </div>
    <div id="completionDiv">
        <div class="completion-content">
            <p>You finished the quiz</p>
            <p id="totalPointsText"></p>
            <a href="http://localhost/szerveroldali/laci_verzio/quiz/index.php"><button>Kilépés</button></a>
        </div>
    </div>
    <div id="confirmationDiv">
        <div class="confirmation-content">
            <p>Biztosan befejezed a kvíz kitöltését?</p>
            <button onclick="finishQuiz()">Igen</button>
            <button onclick="cancelFinish()">Nem</button>
        </div>
    </div>
</div>
</body>
</html>
<?php endif; ?>

<?php
// Close the connection after all queries
$conn->close();
?>